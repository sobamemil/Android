package com.example.exam7_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    lateinit var imgV1 : ImageView
    lateinit var et1 : EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgV1 = findViewById<ImageView>(R.id.imgv1)
        et1 = findViewById<EditText>(R.id.et1)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        var mInflater = menuInflater
        mInflater.inflate(R.menu.menu1, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)

        when(item.itemId) {
            R.id.item1 -> {
                imgV1.setImageResource(R.drawable.ic_launcher_foreground)
                return true
            }

            R.id.item2 -> {
                imgV1.setImageResource(R.drawable.ic_launcher_background)
                return true
            }

            R.id.item3 -> {
                imgV1.setImageResource(R.drawable.ic_launcher_foreground)
                return true
            }

            R.id.imageRotate -> {
                imgV1.rotation = et1.text.toString().toFloat()
                return true
            }
        }

        return false

    }
}