package com.example.project12_2

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import io.realm.Realm
import io.realm.annotations.PrimaryKey
import io.realm.kotlin.createObject
import io.realm.kotlin.where


class MainActivity : AppCompatActivity() {

//    lateinit var myHelper: myDBHelper
    lateinit var edtName: EditText
    lateinit var edtNumber: EditText
    lateinit var edtNameResult: EditText
    lateinit var edtNumberResult: EditText
    lateinit var btnInit: Button
    lateinit var btnInsert: Button
    lateinit var btnUpdate: Button
    lateinit var btnDelete: Button
    lateinit var btnSelect: Button
//    lateinit var sqlDB: SQLiteDatabase

    private val realm = Realm.getDefaultInstance()

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        title = "가수 그룹 관리 DB"

        edtName = findViewById<EditText>(R.id.edtName)
        edtNumber = findViewById<EditText>(R.id.edtNumber)
        edtNameResult = findViewById<EditText>(R.id.edtNameResult)
        edtNumberResult = findViewById<EditText>(R.id.edtNumberResult)

        btnInit = findViewById<Button>(R.id.btnInit)
        btnInsert = findViewById<Button>(R.id.btnInsert)
        btnUpdate = findViewById<Button>(R.id.btnUpdate)
        btnDelete = findViewById<Button>(R.id.btnDelete)
        btnSelect = findViewById<Button>(R.id.btnSelect)

//        myHelper = myDBHelper(this)

        btnInit.setOnClickListener {
//            sqlDB = myHelper.writableDatabase
//            myHelper.onUpgrade(sqlDB, 1, 2) // 인수는 아무거나 입력하면 됨.
//            sqlDB.close()

            realm.beginTransaction()
            realm.deleteAll()
            realm.commitTransaction()

            Toast.makeText(applicationContext, "초기화됨",   Toast.LENGTH_SHORT).show()
        }

        btnInsert.setOnClickListener {
//            sqlDB = myHelper.writableDatabase
//            sqlDB.execSQL("INSERT INTO groupTBL VALUES ( '"
//                    + edtName.text.toString() + "' , "
//                    + edtNumber.text.toString() + ");")
//            sqlDB.close()
//            Toast.makeText(applicationContext, "입력됨",   Toast.LENGTH_SHORT).show()
//            btnSelect.callOnClick()

            realm.beginTransaction()

            val item = realm.createObject<Group>(edtName.text.toString())
            item.gNumber = edtNumber.text.toString().toInt()
            realm.commitTransaction()

            Toast.makeText(applicationContext, "입력됨",   Toast.LENGTH_SHORT).show()

        }

        btnUpdate.setOnClickListener {
//            sqlDB = myHelper.writableDatabase
//            if (edtName.text.toString() !== "") {
//                sqlDB.execSQL("UPDATE groupTBL SET gNumber ="
//                        + edtNumber.text + " WHERE gName = '"
//                        + edtName.text.toString() + "';")
//            }
//            sqlDB.close()
//

//            btnSelect.callOnClick()

            realm.beginTransaction()
            if (edtName.text.toString() !== "") {
                val item = realm.where<Group>().equalTo("gName", edtName.text.toString()).findFirst()
                if (item != null) {
                    item.gNumber = edtNumber.text.toString().toInt()
                    Toast.makeText(applicationContext, "수정됨",  Toast.LENGTH_SHORT).show()
                }
            }
            realm.commitTransaction()
        }

        btnDelete.setOnClickListener {
//            sqlDB = myHelper.writableDatabase
//            if (edtName.text.toString() !== "") {
//                sqlDB.execSQL("DELETE FROM groupTBL WHERE gName = '"
//                        + edtName.text.toString() + "';")
//            }
//            sqlDB.close()

//            btnSelect.call

            realm.beginTransaction()
            if (edtName.text.toString() !== "") {
                val item = realm.where<Group>().equalTo("gName", edtName.text.toString()).findFirst()
                item?.deleteFromRealm()
                Toast.makeText(applicationContext, "삭제됨", Toast.LENGTH_SHORT).show()
            }
            realm.commitTransaction()
        }

        btnSelect.setOnClickListener {
//            sqlDB = myHelper.readableDatabase
//            var cursor: Cursor
//            cursor = sqlDB.rawQuery("SELECT * FROM groupTBL;", null)
//
//            var strNames = "그룹이름" + "\r\n" + "--------" + "\r\n"
//            var strNumbers = "인원" + "\r\n" + "--------" + "\r\n"
//
//            while (cursor.moveToNext()) {
//                strNames += cursor.getString(0) + "\r\n"
//                strNumbers += cursor.getString(1) + "\r\n"
//            }
//
//            edtNameResult.setText(strNames)
//            edtNumberResult.setText(strNumbers)
//
//            cursor.close()
//            sqlDB.close()

            val itemResult = realm.where<Group>().distinct("gName").findAll()
            var strNames = "그룹이름" + "\r\n" + "--------" + "\r\n"
            var strNumbers = "인원" + "\r\n" + "--------" + "\r\n"

            for(item in itemResult) {
                strNames += item.gName + "\r\n"
                strNumbers += item.gNumber.toString() + "\r\n"
            }

            edtNameResult.setText(strNames)
            edtNumberResult.setText(strNumbers)
        }
    }

//
//    inner class myDBHelper(context: Context) : SQLiteOpenHelper(context, "groupDB", null, 1) {
//
//        override fun onCreate(db: SQLiteDatabase) {
//            db.execSQL("CREATE TABLE  groupTBL ( gName CHAR(20) PRIMARY KEY, gNumber INTEGER);")
//        }
//
//        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
//            db.execSQL("DROP TABLE IF EXISTS groupTBL")
//            onCreate(db)
//        }
//    }

    override fun onDestroy() {
        super.onDestroy()
        realm.close()
    }
}