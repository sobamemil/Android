package com.example.project9_1

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import java.util.zip.Inflater

class MainActivity : AppCompatActivity() {
    companion object {
        const val LINE = 1
        const val CIRCLE = 2
        const val RECT = 3
        var curShape = LINE

        const val BLACK = Color.BLACK
        const val BLUE = Color.BLUE
        const val RED = Color.RED
        var curColor = BLACK
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(MyGraphicView(this))
        title = "간단 그림판"

    }

    private class MyGraphicView(context: Context) : View(context) {
        var startX = -1
        var startY = -1
        var stopX = -1
        var stopY = -1

        override fun onTouchEvent(event: MotionEvent?): Boolean {
            super.onTouchEvent(event)
            when(event!!.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x.toInt()
                    startY = event.y.toInt()
                }

                MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                    stopX = event.x.toInt()
                    stopY = event.y.toInt()
                    this.invalidate()
                }
            }
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val paint = Paint()
            paint.isAntiAlias = true
            paint.strokeWidth = 5f
            paint.style = Paint.Style.STROKE
            paint.color = curColor

            when(curShape) {
                LINE -> canvas.drawLine(startX.toFloat(), startY.toFloat(), stopX.toFloat(), stopY.toFloat(), paint)
                CIRCLE -> {
                    var radius = Math.sqrt(Math.pow((stopX - startX).toDouble(), 2.0) + Math.pow((stopY - startY).toDouble(), 2.0))
                    canvas.drawCircle(startX.toFloat(), startY.toFloat(), radius.toFloat(), paint)
                }
                RECT -> {
                    var rect = Rect(startX, startY, stopX, stopY)
                    canvas.drawRect(rect, paint)
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)

        val inflater : MenuInflater = menuInflater
        inflater.inflate(R.menu.menu1, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)

        return when (item.itemId) {
            R.id.option1 -> {
                curShape = LINE
                true
            }

            R.id.option2 -> {
                curShape = CIRCLE
                true
            }

            R.id.option3 -> {
                curShape = RECT
                true
            }

            R.id.subOption1 -> {
                curColor = Color.BLACK
                true
            }

            R.id.subOption2 -> {
                curColor = Color.BLUE
                true
            }

            R.id.subOption3 -> {
                curColor = Color.RED
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}