package com.example.hw2

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.ActionBar
import androidx.fragment.app.FragmentTransaction

@Suppress("deprecation")
class MainActivity : AppCompatActivity(), ActionBar.TabListener {

    lateinit var chrono : Chronometer
    lateinit var rdoCal : RadioButton
    lateinit var rdoTime : RadioButton
    lateinit var calView : CalendarView
    lateinit var tPicker : TimePicker
    lateinit var tvSuccessText : TextView
    lateinit var btnPrev : Button
    lateinit var btnNext : Button
    lateinit var vFlipper : ViewFlipper

    lateinit var tab1 : ActionBar.Tab
    lateinit var tab2 : ActionBar.Tab

    lateinit var tab1Layout : LinearLayout
    lateinit var tab2Layout : LinearLayout

    var myFrags = arrayOfNulls<MyTabFragment>(2)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tab1Layout = findViewById<LinearLayout>(R.id.tab1)
        tab2Layout = findViewById<LinearLayout>(R.id.tab2)

        var year : String = ""
        var month : String = ""
        var day : String = ""
        var hour : String = ""
        var min : String = ""
        var bar = this.supportActionBar
        bar!!.navigationMode = ActionBar.NAVIGATION_MODE_TABS

        tab1 = bar.newTab()
        tab2 = bar.newTab()

        tab1.text = "6-1"
        tab2.text = "6-2"

        tab1.setTabListener(this)
        tab2.setTabListener(this)

        bar.addTab(tab1)
        bar.addTab(tab2)

        title = "HW2"

        chrono = findViewById<Chronometer>(R.id.chronometer1)

        rdoCal = findViewById<RadioButton>(R.id.rdoCal)
        rdoTime = findViewById<RadioButton>(R.id.rdoTime)

        tPicker = findViewById<TimePicker>(R.id.timePicker1)
        calView = findViewById<CalendarView>(R.id.calendarView1)

        tvSuccessText = findViewById<TextView>(R.id.tvSuccessText)

        tPicker.visibility = View.INVISIBLE
        calView.visibility = View.INVISIBLE

        chrono.setOnClickListener {
            chrono.base = SystemClock.elapsedRealtime()
            chrono.start()
            chrono.setTextColor(Color.RED)

            rdoCal.visibility = View.VISIBLE
            rdoTime.visibility = View.VISIBLE

            tvSuccessText.text = "0000년 00월 00일 00시 00분 예약대기"
        }

        tPicker.setOnTimeChangedListener { timePicker, i, i2 ->
            hour = i.toString()
            min = i2.toString()
        }


        rdoCal.setOnClickListener {
            tPicker.visibility = View.INVISIBLE
            calView.visibility = View.VISIBLE
        }

        rdoTime.setOnClickListener {
            tPicker.visibility = View.VISIBLE
            calView.visibility = View.INVISIBLE
        }

        tvSuccessText.setOnLongClickListener {
            chrono.stop()
            chrono.setTextColor(Color.BLUE)
            tvSuccessText.text = year + "년" + month + "월" + day + "일" + hour + "시" + min + "분 예약됨"

            tPicker.visibility = View.INVISIBLE
            rdoCal.visibility = View.INVISIBLE
            rdoTime.visibility = View.INVISIBLE
            calView.visibility = View.INVISIBLE

            return@setOnLongClickListener(true)
        }

        calView.setOnDateChangeListener { calendarView, i, i2, i3 ->
            year = i.toString()
            month = i2.toString()
            day = i3.toString()

        }

        btnPrev = findViewById<Button>(R.id.btnPrev)
        btnNext = findViewById<Button>(R.id.btnNext)
        vFlipper = findViewById<ViewFlipper>(R.id.viewFlipper1)

        btnPrev.setOnClickListener {
            vFlipper.flipInterval = 1000 // 단위 ms
            vFlipper.visibility = View.VISIBLE
            vFlipper.startFlipping()
        }

        btnNext.setOnClickListener {
            vFlipper.stopFlipping()
            vFlipper.visibility = View.INVISIBLE
        }

        vFlipper.setOnClickListener {
            var toast = Toast.makeText(applicationContext, vFlipper.currentView.tag.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onTabSelected(tab: ActionBar.Tab, ft: FragmentTransaction) {
        var myTabFrag : MyTabFragment? = null

        if (myFrags[tab.position] == null) {
            myTabFrag = MyTabFragment()
            val data = Bundle()
            data.putString("tabName", tab.text.toString())
            myTabFrag.arguments = data
            myFrags[tab.position] = myTabFrag
        } else {
            myTabFrag = myFrags[tab.position]
        }

        if(tab.position == 0) {
            tab1Layout.visibility = View.VISIBLE
            tab2Layout.visibility = View.INVISIBLE
        }

        if(tab.position == 1) {
            tab1Layout.visibility = View.INVISIBLE
            tab2Layout.visibility = View.VISIBLE
        }

        ft.replace(android.R.id.content, myTabFrag!!)
    }
    override fun onTabUnselected(tab: ActionBar.Tab?, ft: FragmentTransaction?) {}
    override fun onTabReselected(tab: ActionBar.Tab?, ft: FragmentTransaction?) {}

    class MyTabFragment : androidx.fragment.app.Fragment() {
        var tabName : String? = null
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            var data = arguments
            tabName = data!!.getString("tabName")
        }

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
           // var params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)

//            var baseLayout = LinearLayout(super.getActivity())
//            baseLayout.orientation = LinearLayout.VERTICAL
//            baseLayout.layoutParams = params
            var baseLayout = inflater.inflate(R.layout.activity_main, null)

            return baseLayout
        }
    }
}
