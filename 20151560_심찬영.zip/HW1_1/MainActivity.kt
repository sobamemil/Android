package com.example.hw_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.*
import android.widget.*
import androidx.core.graphics.rotationMatrix

class MainActivity : AppCompatActivity() {
    lateinit var swVisible : Switch
    lateinit var imgView1 : ImageView
    lateinit var rGroup1 : RadioGroup
    lateinit var rGroup2 : RadioGroup
    lateinit var btnReset : Button
    lateinit var editText1 : EditText
    lateinit var btnOK : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swVisible = findViewById<Switch>(R.id.SwVisible)
        imgView1 = findViewById<ImageView>(R.id.ImageV)
        rGroup1 = findViewById<RadioGroup>(R.id.radioGroup1)
        rGroup2 = findViewById<RadioGroup>(R.id.radioGroup2)
        btnReset = findViewById<Button>(R.id.BtnReset)
        editText1 = findViewById<EditText>(R.id.editText1)
        btnOK = findViewById<Button>(R.id.BtnOK)

        btnOK.setOnClickListener {
            imgView1.setRotation(editText1.text.toString().toFloat())
        }

        swVisible.setOnCheckedChangeListener { compoundButton, b ->
            if (b == true) {
                when(rGroup1.checkedRadioButtonId) {
                    R.id.image1-> {
                        when(rGroup2.checkedRadioButtonId) {
                            R.id.fitStart -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.center -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.fitXY -> imgView1.visibility = android.view.View.VISIBLE
                            else -> Toast.makeText(applicationContext, "스케일을 먼저 선택하세요.", Toast.LENGTH_SHORT).show()
                        }
                    }
                    R.id.image2-> {
                        when(rGroup2.checkedRadioButtonId) {
                            R.id.fitStart -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.center -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.fitXY -> imgView1.visibility = android.view.View.VISIBLE
                            else -> Toast.makeText(applicationContext, "스케일을 먼저 선택하세요.", Toast.LENGTH_SHORT).show()
                        }
                    }
                    R.id.image3-> {
                        when(rGroup2.checkedRadioButtonId) {
                            R.id.fitStart -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.center -> imgView1.visibility = android.view.View.VISIBLE
                            R.id.fitXY -> imgView1.visibility = android.view.View.VISIBLE
                            else -> Toast.makeText(applicationContext, "스케일을 먼저 선택하세요.", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else -> Toast.makeText(applicationContext, "이미지를 먼저 선택하세요.", Toast.LENGTH_SHORT).show()
                }

            } else if (b == false){
                imgView1.visibility = android.view.View.INVISIBLE
            }
        }

        rGroup1.setOnCheckedChangeListener { radioGroup, i ->
            when(rGroup1.checkedRadioButtonId) {
                R.id.image1 -> imgView1.setImageResource(R.drawable.airplane2)
                R.id.image2 -> imgView1.setImageResource(R.drawable.bus2)
                R.id.image3 -> imgView1.setImageResource(R.drawable.koreamap3)
            }
        }

        rGroup2.setOnCheckedChangeListener { radioGroup, i ->
            when(rGroup2.checkedRadioButtonId) {
                R.id.fitStart -> imgView1.scaleType = ImageView.ScaleType.FIT_START
                R.id.center -> imgView1.scaleType = ImageView.ScaleType.FIT_CENTER
                R.id.fitXY -> imgView1.scaleType = ImageView.ScaleType.FIT_XY
            }
        }

        btnReset.setOnClickListener {
            imgView1.visibility = android.view.View.INVISIBLE
            rGroup1.clearCheck()
            rGroup2.clearCheck()
            swVisible.isChecked = false
            imgView1.setRotation(0f)
            editText1.text.clear()
        }
    }
}