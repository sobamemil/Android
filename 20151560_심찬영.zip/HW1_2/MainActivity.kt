package com.example.hw_1_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    lateinit var btnThreeP1 : Button
    lateinit var btnThreeP2 : Button
    lateinit var btnTwoP1 : Button
    lateinit var btnTwoP2 : Button
    lateinit var btnFT1 : Button
    lateinit var btnFT2 : Button
    lateinit var btnReset : Button
    lateinit var textCount1 : TextView
    lateinit var textCount2 : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnThreeP1 = findViewById<Button>(R.id.btnThreeP1)
        btnThreeP2 = findViewById<Button>(R.id.btnThreeP2)
        btnTwoP1 = findViewById<Button>(R.id.btnTwoP1)
        btnTwoP2 = findViewById<Button>(R.id.btnTwoP2)
        btnFT1 = findViewById<Button>(R.id.btnFT1)
        btnFT2 = findViewById<Button>(R.id.btnFT2)
        btnReset = findViewById<Button>(R.id.btnReset)

        textCount1 = findViewById<TextView>(R.id.textCount1)
        textCount2 = findViewById<TextView>(R.id.textCount2)

        btnThreeP1.setOnClickListener {
            textCount1.setText(Integer.toString(textCount1.text.toString().toInt() + 3))
        }

        btnThreeP2.setOnClickListener {
            textCount2.setText(Integer.toString(textCount2.text.toString().toInt() + 3))
        }

        btnTwoP1.setOnClickListener {
            textCount1.setText(Integer.toString(textCount1.text.toString().toInt() + 2))
        }

        btnTwoP2.setOnClickListener {
            textCount2.setText(Integer.toString(textCount2.text.toString().toInt() + 2))
        }

        btnFT1.setOnClickListener {
            textCount1.setText(Integer.toString(textCount1.text.toString().toInt() + 1))
        }

        btnFT2.setOnClickListener {
            textCount2.setText(Integer.toString(textCount2.text.toString().toInt() + 1))
        }

        btnReset.setOnClickListener {
            textCount1.text = "0"
            textCount2.text = "0"
        }
    }
}