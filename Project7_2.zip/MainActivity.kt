package com.example.project7_2

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.RelativeLayout

class MainActivity : AppCompatActivity() {

    lateinit var btn1 : Button
    lateinit var btn2 : Button
    lateinit var baseLayout : RelativeLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn1 = findViewById<Button>(R.id.btn1)
        btn2 = findViewById<Button>(R.id.btn2)
        baseLayout = findViewById<RelativeLayout>(R.id.baseLayout)

        registerForContextMenu(btn1)
        registerForContextMenu(btn2)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        var mInflater = menuInflater

        when (v) {
            btn1 -> {
                menu!!.setHeaderTitle("배경색 변경")
                mInflater.inflate(R.menu.menu1, menu)
            }

            btn2 -> {
                menu!!.setHeaderTitle("버튼 변경")
                mInflater.inflate(R.menu.menu2, menu)
            }
        }
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        super.onContextItemSelected(item)

        when(item.itemId) {
            R.id.red -> {
                baseLayout.setBackgroundColor(Color.RED)
                return true
            }

            R.id.green -> {
                baseLayout.setBackgroundColor(Color.GREEN)
                return true
            }

            R.id.blue -> {
                baseLayout.setBackgroundColor(Color.BLUE)
                return true
            }

            R.id.rotate -> {
                btn2.rotation = 45f
                return true
            }

            R.id.scale -> {
                btn2.scaleX = 2f
                return true
            }
        }
        return false
    }
}