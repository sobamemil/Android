package com.example.question7_4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var tp1 : TimePicker
    private lateinit var cv1 : CalendarView
    private lateinit var rdoGroup1 : RadioGroup
    private lateinit var rdoGroupButton : Button
    private lateinit var contextButton1 : Button
    private lateinit var rdo1 : RadioButton
    private lateinit var rdo2 : RadioButton
    private lateinit var rdo3 : RadioButton
    private lateinit var rdo4 : RadioButton
    private lateinit var rdo5 : RadioButton
    private lateinit var toastView : View
    private lateinit var toastText : TextView
    private lateinit var dlgTv1 : TextView
    private lateinit var dialogView : View
    private lateinit var btnTp : Button
    private lateinit var btnCv : Button
    private lateinit var dlgViewFlipper : ViewFlipper
    private lateinit var dlgCloseButton : Button
    private lateinit var dlgNextButton : Button

    private lateinit var linearLayout1 : LinearLayout
    private lateinit var linearLayout2 : LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "HW3"

        tp1 = findViewById<TimePicker>(R.id.tp1)
        cv1 = findViewById<CalendarView>(R.id.cv1)
        rdoGroup1 = findViewById<RadioGroup>(R.id.rdoGroup1)
        rdoGroupButton = findViewById<Button>(R.id.rdoGroupButton)
        contextButton1 = findViewById<Button>(R.id.contextButton1)
        rdo1 = findViewById<RadioButton>(R.id.rdo1)
        rdo2 = findViewById<RadioButton>(R.id.rdo2)
        rdo3 = findViewById<RadioButton>(R.id.rdo3)
        rdo4 = findViewById<RadioButton>(R.id.rdo4)
        rdo5 = findViewById<RadioButton>(R.id.rdo5)
        btnTp = findViewById<Button>(R.id.btnTp)
        btnCv = findViewById<Button>(R.id.btnCv)
        linearLayout1 = findViewById<LinearLayout>(R.id.linearLayout1)
        linearLayout2 = findViewById<LinearLayout>(R.id.linearLayout2)

        registerForContextMenu(contextButton1)

        var year = Calendar.getInstance().get(Calendar.YEAR).toString()
        var month = (Calendar.getInstance().get(Calendar.MONTH).toString().toInt() + 1).toString()
        var day = Calendar.getInstance().get(Calendar.DATE).toString()
        var hour = tp1.currentHour.toString()
        var minute = tp1.currentMinute.toString()

        tp1.setOnTimeChangedListener { _, i, i2 ->
            hour = i.toString()
            minute = i2.toString()
        }

        cv1.setOnDateChangeListener { _, i, i2, i3 ->
            year = i.toString()
            month = (i2.toString().toInt() + 1).toString()
            day = i3.toString()
        }

        btnTp.setOnClickListener {
            val toast = Toast(this@MainActivity)
            toastView = View.inflate(this@MainActivity, R.layout.toast1, null)
            toastText = toastView.findViewById<TextView>(R.id.toastTv1)
//            if(hour.isEmpty() || minute.isEmpty()) {
//                toastText.text = "시간이 선택되지 않았습니다."
//            }
            toastText.text = "선택된 시간은 " + hour + "시 " + minute + "분 입니다."
            toast.view = toastView
            toast.show()
        }

        btnCv.setOnClickListener {
            val toast = Toast(this@MainActivity)
            toastView = View.inflate(this@MainActivity, R.layout.toast1, null)
            toastText = toastView.findViewById<TextView>(R.id.toastTv1)
            toastText.text = "선택된 날짜는 " + year + "년 " + month + "월 " + day + "일 입니다."
            toast.view = toastView
            toast.show()
        }


        rdoGroupButton.setOnClickListener {
            dialogView = View.inflate(this@MainActivity, R.layout.dialog1, null)
            val dlg = AlertDialog.Builder(this@MainActivity)
            val ad = dlg.create()
            dlgCloseButton = dialogView.findViewById<Button>(R.id.dlgCloseButton)
            dlgNextButton = dialogView.findViewById<Button>(R.id.dlgNextButton)
            dlgViewFlipper = dialogView.findViewById<ViewFlipper>(R.id.dlgViewFilpper1)

            dlgCloseButton.setOnClickListener {
                ad.dismiss()
            }

            dlgNextButton.setOnClickListener {
                dlgViewFlipper.showNext()
                dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
            }

            dlgTv1 = dialogView.findViewById<TextView>(R.id.dlgTv1)

            when (rdoGroup1.checkedRadioButtonId) {
                rdo1.id -> {
                    dlgViewFlipper.displayedChild = 0
                    dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
                    ad.setView(dialogView)
                    ad.show()
                }

                rdo2.id -> {
                    dlgViewFlipper.displayedChild = 1
                    dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
                    ad.setView(dialogView)
                    ad.show()
                }

                rdo3.id -> {
                    dlgViewFlipper.displayedChild = 2
                    dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
                    ad.setView(dialogView)
                    ad.show()
                }

                rdo4.id -> {
                    dlgViewFlipper.displayedChild = 3
                    dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
                    ad.setView(dialogView)
                    ad.show()
                }

                rdo5.id -> {
                    dlgViewFlipper.displayedChild = 4
                    dlgTv1.text = dlgViewFlipper.currentView.tag.toString()
                    ad.setView(dialogView)
                    ad.show()
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menu!!.add(0, 1, 0, "TimePicker")
        menu.add(0, 2, 0, "CalendarView")
        menu.add(0, 3, 0, "SelectImage")
        menu.add(0, 4, 0, "초기화면")

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        super.onOptionsItemSelected(item)

        when (item.itemId) {
            1 -> {
                linearLayout1.visibility = View.VISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            2 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.VISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            3 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.VISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            4 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.VISIBLE
                return true
            }
        }
        return false
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        menu!!.add(0, 1, 0, "TimePicker")
        menu.add(0, 2, 0, "CalendarView")
        menu.add(0, 3, 0, "SelectImage")
        menu.add(0, 4, 0, "초기화면")
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        super.onContextItemSelected(item)

        when (item.itemId) {
            1 -> {
                linearLayout1.visibility = View.VISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            2 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.VISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            3 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.VISIBLE
                contextButton1.visibility = View.INVISIBLE
                return true
            }

            4 -> {
                linearLayout1.visibility = View.INVISIBLE
                linearLayout2.visibility = View.INVISIBLE
                rdoGroup1.visibility = View.INVISIBLE
                contextButton1.visibility = View.VISIBLE
                return true
            }
        }
        return true
    }

}