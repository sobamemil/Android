package com.example.hw4

data class ListViewItem(val name: String, val title: String, val detail: String)