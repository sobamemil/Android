package com.example.hw4

import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class ThirdActivity : AppCompatActivity() {
    lateinit var imageView : ImageView
    lateinit var toolbar : Toolbar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.third_view)

        toolbar = findViewById(R.id.third_toolbar)

        // 액션바 설정
        setSupportActionBar(toolbar)
        supportActionBar?.title = "큰 사진"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        imageView = findViewById(R.id.imageView)

        // 인텐트를 통해 넘어온 데이터 저장
        val intent = intent
        val imageName = intent.getStringExtra("imageName")
        val resId = resources.getIdentifier(imageName, "drawable", "com.example.hw4")
        imageView.setImageResource(resId)
    }

    // 뒤로가기 클릭에 대한 이벤트 콜백
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                //toolbar의 back키 눌렀을 때 동작
                // 액티비티 이동
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}