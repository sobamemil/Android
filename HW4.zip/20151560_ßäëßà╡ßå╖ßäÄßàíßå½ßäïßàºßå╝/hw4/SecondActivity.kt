package com.example.hw4

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.PersistableBundle
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class SecondActivity : AppCompatActivity() {
    lateinit var title : TextView
    lateinit var name : TextView
    lateinit var detail : TextView
    lateinit var toolbar : Toolbar

    lateinit var imageCustomView : ImageCustomView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.second_view)

        title = findViewById(R.id.second_title)
        name = findViewById(R.id.second_name)
        detail = findViewById(R.id.second_detail)
        toolbar = findViewById(R.id.second_toolbar)

        // 액션바 설정
        setSupportActionBar(toolbar)
        supportActionBar?.title = "시"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // 인텐트를 통해 넘어온 데이터 저장
        val intent = intent

        title.text = intent.getStringExtra("title")
        name.text = intent.getStringExtra("name")
        detail.text = intent.getStringExtra("detail")

        // 커스텀뷰 적용
        imageCustomView = findViewById<ImageCustomView>(R.id.ImageCustomView)
        var imageName = name.text.toString()
        when(imageName) {
            "이정하" -> {
                imageName = "poem1"
            }
            "김용택" -> {
                imageName = "poem2"
            }
            "백석" -> {
                imageName = "poem3"
            }
            "곽재구" -> {
                imageName = "poem4"
            }
            "기형도" -> {
                imageName = "poem5"
            }
        }
        imageCustomView.imageName = imageName

        imageCustomView.setOnClickListener {
            // 인텐트를 사용하여 시 상세 화면으로 액티비티 전환
            val intent = Intent(applicationContext, ThirdActivity::class.java)
            intent.putExtra("imageName", imageName)
            startActivity(intent)
        }
    }

    // 뒤로가기 클릭에 대한 이벤트 콜백
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                //toolbar의 back키 눌렀을 때 동작
                // 액티비티 이동
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}