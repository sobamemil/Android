package com.example.hw4

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.res.ResourcesCompat.getDrawable

class ImageCustomView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var imageName : String? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        try {
            if(imageName != null) {
                val resId = resources.getIdentifier(imageName, "drawable", "com.example.hw4")
                var bitmap = BitmapFactory.decodeResource(this.resources, resId)
                canvas.scale(0.7f, 0.7f, )
                canvas.drawBitmap(bitmap!!, 0f, 0f, null)
                bitmap!!.recycle()
            }
        } catch (e : Exception) {
            TODO("error catch")
        }
    }
}