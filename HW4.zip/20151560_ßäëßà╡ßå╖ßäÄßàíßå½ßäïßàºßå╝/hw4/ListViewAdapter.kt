package com.example.hw4

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView


class ListViewAdapter(private val items: MutableList<ListViewItem>): BaseAdapter() {
    override fun getCount(): Int = items.size

    override fun getItem(position: Int): ListViewItem = items[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        var convertView = view
        if (convertView == null) convertView = LayoutInflater.from(parent?.context).inflate(R.layout.detail_view, parent, false)

        val item: ListViewItem = items[position]
        convertView!!.findViewById<TextView>(R.id.tvTitle).text = item.title
        convertView!!.findViewById<TextView>(R.id.tvName).text = item.name
        convertView!!.findViewById<TextView>(R.id.tvDetail).text = item.detail

        return convertView
    }
}
