package com.example.hw4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.*

class MainActivity : AppCompatActivity() {
    lateinit var listView : ListView

    var title : String = ""
    var name : String = ""
    var detail : String = ""

    // 내장 메모리에 파일을 저장하는 메소드
    fun writeTextToFile(path: String, title: String, name: String, detail: String) {
        val file = File(path)
        val fileWriter = FileWriter(file, false)
        val bufferedWriter = BufferedWriter(fileWriter)

        bufferedWriter.append(title)
        bufferedWriter.newLine()
        bufferedWriter.append(name)
        bufferedWriter.newLine()
        bufferedWriter.append(detail + "\n")
        bufferedWriter.close()
    }

    // 내장 메모리에서 파일을 읽어오는 메소드
    fun readTextFromFile(path: String) {
        val file = File(path)
        val fileReader = FileReader(file)
        val bufferedReader = BufferedReader(fileReader)
        var cnt = 0
        detail = ""

        bufferedReader.readLines().forEach() {
            when(cnt++) {
                0 -> {
                    title = it
                }
                1 -> {
                    name = it
                }

                else -> {
                    detail += it + "\n"
                }
            }
        }


    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 시를 내장 메모리에 파일로 저장하는 부분
        val filePath1 = filesDir.path + "/poem1.txt"
        val filePath2 = filesDir.path + "/poem2.txt"
        val filePath3 = filesDir.path + "/poem3.txt"
        val filePath4 = filesDir.path + "/poem4.txt"
        val filePath5 = filesDir.path + "/poem5.txt"
        writeTextToFile(filePath1, "낮은곳으로","이정하", poem1)
        writeTextToFile(filePath2, "달이 떴다고 전화를 주시다니요", "김용택", poem2)
        writeTextToFile(filePath3, "여승", "백석", poem3)
        writeTextToFile(filePath4, "사평역에서", "곽재구", poem4)
        writeTextToFile(filePath5, "빈집", "기형도", poem5)

        // 리스트 뷰에 아이템을 추가하는 부분
        val items = mutableListOf<ListViewItem>()
        for(num in 1..5) {
            // 시를 내장 메모리에서 읽어오는 부분
            val filePath = filesDir.path + "/poem" + num + ".txt"
            readTextFromFile(filePath)

            items.add(ListViewItem(name, title, detail))
        }

        listView = findViewById(R.id.listView)
        val adapter = ListViewAdapter(items)
        listView.adapter = adapter
        listView.setOnItemClickListener {
                parent: AdapterView<*>, view: View, position: Int, id: Long ->
            val item = parent.getItemAtPosition(position) as ListViewItem

            // 인텐트를 사용하여 시 상세 화면으로 액티비티 전환
            val intent = Intent(applicationContext, SecondActivity::class.java)
            intent.putExtra("title", item.title)
            intent.putExtra("name", item.name)
            intent.putExtra("detail", item.detail)
            startActivity(intent)
        }

    }

    private val poem1 = "낮은 곳에 있고 싶었다. \n" +
            "낮은 곳이라면 지상의 그 어디라도 좋다. \n" +
            "찰랑 찰랑 고여들 \n" +
            "네 사랑을 온 몸으로 \n" +
            "받아들 일 수만 있다면 \n" +
            "\n" +
            "한 방울도 헛되이 \n" +
            "새어나가지 않게 할 수 있다면 \n" +
            "그래, 내가 \n" +
            "낮은 곳에 있겠다는 건 \n" +
            "너를 위해 나를 온전히 \n" +
            "비우겠다는 것이다. \n" +
            "\n" +
            "잠겨 죽어도 좋으니 \n" +
            "너는 물처럼 내게 밀려오라. "

    private val poem2 = "달이 떴다고 전화를 주시다니요\n" +
            "이 밤 너무나 신나고 근사해요\n" +
            "내 마음에도 생전 처음 보는 \n" +
            "환한 달이 떠오르고\n" +
            "산 아래 작은 마을이 그려집니다.\n" +
            "간절한 이 그리움들을\n" +
            "사무쳐오는 이 연정들을\n" +
            "달빛에 실어\n" +
            "당신께 보냅니다.\n" +
            "\n" +
            "세상에\n" +
            "강변에 달빛이 곱다고 \n" +
            "전화를 다 주시다니요\n" +
            "흐르는 물 어디쯤 눈부시게 부서지는 소리\n" +
            "문득 들려옵니다"

    private val poem3 = "여승은 합장하고 절을 했다. \n" +
            "가지취의 내음새가 났다. \n" +
            "쓸쓸한 낯이 옛날같이 늙었다. \n" +
            "나는 불경처럼 서러워졌다. \n" +
            "\n" +
            "평안도의 어늬 산 깊은 금점판 \n" +
            "나는 파리한 여인에게서 옥수수를 샀다. \n" +
            "여인은 나어린 딸을 때리며 가을밤같이 차게 울었다. \n" +
            "\n" +
            "섶벌같이 나아간 지아비 기다려 십 년이 갔다. \n" +
            "지아비는 돌아오지 않고 \n" +
            "어린 딸은 도라지 꽃이 좋아 돌무덤으로 갔다. \n" +
            "\n" +
            "산꿩도 설게 울은 슬픈 날이 있었다. \n" +
            "산정의 마당귀에 여인의 머리오리가 눈물방울과 같이 떨어진 날이 있었다. \n"

    private val poem4 = "막차는 좀처럼 오지 않았다 \n" +
            "대합실 밖에는 밤새 송이눈이 쌓이고 \n" +
            "흰 보라 수수꽃 눈시린 유리창마다 \n" +
            "톱밥난로가 지펴지고 있었다 \n" +
            "그믐처럼 몇은 졸고 \n" +
            "몇은 감기에 쿨럭이고 \n" +
            "그리웠던 순간들을 생각하며 나는 \n" +
            "한줌의 톱밥을 불빛 속에 던져 주었다 \n" +
            "\n" +
            "내면 깊숙이 할 말들은 가득해도 \n" +
            "청색의 손 바닥을 불빛 속에 적셔두고 \n" +
            "모두들 아무 말도 하지 않았다 \n" +
            "\n" +
            "산다는 것이 때론 술에 취한 듯 \n" +
            "한 두릅의 굴비 한 광주리의 사과를 \n" +
            "만지작 거리며 귀향하는 기분으로 \n" +
            "침묵해야 한다는 것을 \n" +
            "모두들 알고 있었다 \n" +
            "\n" +
            "오래 앓은 기침소리와 \n" +
            "쓴약 같은 입술담배 연기 속에서 \n" +
            "싸륵싸륵 눈꽃은 쌓이고 \n" +
            "그래 지금은 모두들 \n" +
            "눈꽃의 화음에 귀를 적신다 \n" +
            "\n" +
            "자정 넘으면 \n" +
            "낯설음도 뼈아픔도 다 설원인데 \n" +
            "단풍잎 같은 몇 잎의 차장을 달고 \n" +
            "밤열차는 또 어디로 흘러가는지 \n" +
            "\n" +
            "그리웠던 순간들을 호명하며 나는 \n" +
            "한줌의 눈물을 불빛 속에 던져주었다 "

    private val poem5 = "사랑을 잃고 나는 쓰네 \n" +
            "\n" +
            "잘 있거라, 짧았던 밤들아 \n" +
            "창밖을 떠돌던 겨울 안개들아 \n" +
            "아무것도 모르던 촛불들아, 잘 있거라 \n" +
            "공포를 기다리던 흰 종이들아 \n" +
            "망설임을 대신하던 눈물들아 \n" +
            "잘 있거라, 더 이상 내 것이 아닌 열망들아 \n" +
            "\n" +
            "장님처럼 나 이제 더듬거리며 문을 잠그네 \n" +
            "가엾은 내 사랑 빈집에 갇혔네 "

}

