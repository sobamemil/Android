package com.example.project8_1

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

open class Group : RealmObject() {
    @PrimaryKey
    var gName : String = ""
    var gText : String = ""
}