package com.example.project8_1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.Toast
import io.realm.Realm
import io.realm.kotlin.createObject
import io.realm.kotlin.where
import java.io.FileInputStream
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var dp1 : DatePicker
    lateinit var et1 : EditText
    lateinit var btn1 : Button
    lateinit var btn2 : Button
    lateinit var fileName : String

    private val realm = Realm.getDefaultInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dp1 = findViewById<DatePicker>(R.id.dp1)
        et1 = findViewById<EditText>(R.id.et1)
        btn1 = findViewById<Button>(R.id.btn1)
        btn2 = findViewById<Button>(R.id.btn2)

        var cal = Calendar.getInstance()
        var cYear = cal.get(Calendar.YEAR)
        var cMonth = cal.get(Calendar.MONTH)
        var cDay = cal.get(Calendar.DAY_OF_MONTH)

        dp1.init(cYear, cMonth, cDay) { view, year, monthOfYear, dayOfMonth ->
            fileName = (year.toString() + "_" + monthOfYear.toString() + "_" + dayOfMonth.toString() + ".txt")
//            var str = readDiary(fileName)
//            et1.setText(str)
//            btn1.isEnabled = true

            realm.beginTransaction()
            val item = realm.where<Group>().equalTo("gName", fileName).findFirst()
            if(item != null) {
                et1.setText(item.gText)
                btn1.text = "수정하기"
                btn2.isEnabled = true
            } else {
                et1.text = null
                et1.hint = "일기 없음"
                btn1.text = "새로 저장"
                btn2.isEnabled = false
            }

            btn1.isEnabled = true
            realm.commitTransaction()
        }

        btn1.setOnClickListener {
//            var outFs = openFileOutput(fileName, Context.MODE_PRIVATE)
//            var str = et1.text.toString()
//            outFs.write(str.toByteArray())
//            outFs.close()

            realm.beginTransaction()
            if(et1.text.toString() !== "") {
                var item = realm.where<Group>().equalTo("gName", fileName).findFirst()
                if(item == null) {
                    item = realm.createObject<Group>(fileName)
                    item.gText = et1.text.toString()
                } else {
                    item.gText = et1.text.toString()
                }
                btn1.text = "수정하기"
                btn2.isEnabled = true
                Toast.makeText(applicationContext, "$fileName 이 저장됨", Toast.LENGTH_SHORT).show()
            }
            realm.commitTransaction()
        }

        btn2.setOnClickListener {
            realm.beginTransaction()
            val item = realm.where<Group>().equalTo("gName", fileName).findFirst()
            item?.deleteFromRealm()
            btn1.text = "새로 저장"
            btn2.isEnabled = false
            et1.text = null
            Toast.makeText(applicationContext, "삭제됨", Toast.LENGTH_SHORT).show()
            realm.commitTransaction()
        }
    }


//    fun readDiary(fName: String) : String? {
//        var diaryStr : String? = null
//        var inFs : FileInputStream
//        try {
//            inFs = openFileInput(fName)
//            var txt = ByteArray(inFs.available())
//            inFs.read(txt)
//            inFs.close()
//            diaryStr = txt.toString(Charsets.UTF_8).trim()
//            btn1.text = "수정하기"
//        } catch (e : IOException) {
//            et1.hint = "일기 없음"
//            btn1.text = "새로 저장"
//        }
//        return diaryStr
//    }

}